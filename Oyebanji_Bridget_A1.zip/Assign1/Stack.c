/*	Stack.c
 *      Bridget Oyebanji - #3548868
 ******************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int top = 0;
bool is_whitespace(char in);
void print_stack(int *stack, int *size);
bool push(int *stack, int *size, int max_size, int to_push);
bool pop(int *stack, int *size, int *to_return);
bool peek(int *stack, int *size, int *to_return);



bool is_whitespace(char in)
{
	return (in == ' ' || in == '\t' || in == '\n' || in == '\r');
}

/**
 * function:
 *		print_stack
 *
 * expects:
 *		a pointer to the root of the stack 
 *		a pointer to the current size of the stack
 * 
 * Prints a visual representation of the current state of the stack
 */
void print_stack(int *stack, int *size)
{
	for(int i=0; i<(*size); i++)
	{
		printf("|_ %d _|\n", stack[i] );
	}
	printf("%d elements\n", (*size) );
}

/**
 * function:
 *		push
 *
 * expects:
 *		pointer to the stack
 *		pointer to the size
 *		the value to push
 *
 * returns:
 *  	true when value has been pushed
 *		false otherwise
 *
 * The push function push a value to the passed in stack
 */
bool push(int *stack, int *size, int max_size, int to_push)
{
	int flag;

	if((*size) >= max_size-1)
        {
               flag = 1;
	       
        }
	else 
	{
		if((*size) == 0)
        	{
               	    stack[*size]=to_push;
	       	    flag = 0;
	            (*size)++;
        	}
	
		else
		{       
	            stack[*size]=to_push;
	            flag = 0;
	            (*size)++;
		}
	}
	return (flag == 0);
}

/**
 * function:
 *		pop
 *
 * expects:
 *		pointer to the stack
 *		pointer to the size
 *		pointer to location to store the popped value
 *
 * returns:
 *  	true when value has been popped
 *		false otherwise
 *
 * The pop function pops a value from the passed in stack and stores it at the to_return location.
 */
bool pop(int *stack, int *size, int *to_return)
{
	

	if((*size)<=0)
        {
	       return false;
        }

	else{       
	       *to_return=stack[*size-1];
	       (*size)--;
	       return true;
	}
	
}

/**
 * function:
 *		peek
 *
 * expects:
 *		pointer to the stack
 *		pointer to the size
 *		pointer to location to store the popped value
 *
 * returns:
 *  	true when value has been peeked
 *		false otherwise
 *
 * The peek function looks at the top value from the stack and stores it at the to_return location.
 */
bool peek(int *stack, int *size, int *to_return)
{

	if((*size)<=0)
        {  
	       return false;
        }

	else{       
	       *to_return=stack[*size-1];
	        return true;
	}
}


int main( int argc, char **argv )
{
	// keep track of the max size and the current size of the stack
	int stack_max_size = 5;
	int stack_current_size = 0;
	int ret, value;

	// the stack is an array located on the main() function stack frame
	int stack[stack_max_size];

	// initialize our stack with 0 values
	for(int i=0; i < stack_max_size; i++)
	{
		stack[i] = 0;
	}

	// count the number of instructions (peek, pop, push) that successfully happened 
	int successful_instructions = 0;
	bool stop_execution = false;

	while(!stop_execution)
	{
		// read the input instruction (a single character)
		char input_instruction = 0;
		int value;
		scanf("%c", &input_instruction);

		// the character could be a whitespace so we need to skip those
		if( false == is_whitespace(input_instruction) )
		{
			if (input_instruction == 'u'){
                        	scanf("%d", &value);
 				//push the read value onto the stack
 				if ( false == push(stack, &stack_current_size, stack_max_size, value) )
				{
 				printf("failed push\n");
			
				}
 				else{
 					printf("%d\n", value);
					successful_instructions++;
				}
			}
	
 	                else if (input_instruction == 'o'){
 			//we execute the pop function
 				if ( false == pop(stack, &stack_current_size, &ret) )
 				{	
					printf("failed pop\n");
				}
 				else{
 					printf("%d\n", ret);
					successful_instructions++;
				}
                	}

 			else if (input_instruction == 'e'){
 			//we execute the peek function
 				if ( false == peek(stack, &stack_current_size, &value) )
 				{	
					printf("failed peek\n");
				}
 				else{
 					printf("%d\n", value);
					successful_instructions++;
				}
                	}
 			else if (input_instruction == 'x'){
				stop_execution = true;
 				break;
 			}

 			else{
 				printf("invalid instruction %c\n", input_instruction);
 			}
		}
	}

	printf("Successfully executed %d instructions\n", successful_instructions);
 	print_stack(stack, &stack_current_size);

	return EXIT_SUCCESS;
}
