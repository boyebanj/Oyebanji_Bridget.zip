# Bridget Oyebanji CS2263_A1

## Purpose

Practice array based stacks, introduce git and make basic usage.  

Functions include:

- the main function
- the push function
- the pop function
- the peek function


